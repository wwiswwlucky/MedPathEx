# HDGAT
## Enviroment settings

1. numpy == 1.21.5
2. tensorflow ==2.11.0
3. keras ==2.11.0
4. scipy ==1.7.3

## How to run the code?
1. cd code
2. python main.py
