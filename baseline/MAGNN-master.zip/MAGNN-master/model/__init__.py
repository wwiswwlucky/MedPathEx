from model.MAGNN_nc import MAGNN_nc
from model.MAGNN_nc_mb import MAGNN_nc_mb
from model.MAGNN_lp import MAGNN_lp
