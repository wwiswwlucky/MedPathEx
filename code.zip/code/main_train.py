import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam

from data import load_adjs, adj_to_edge_list, build_initial_features
from split import kfold_split_edges, remove_edges_from_adj, negative_sample

from similarity_encoder import build_similarity_embeddings, load_similarity_matrix
from metapath import MetaPathSampler, MetaPathEncoderInstance
from global_attention import concat_hetero_edges
from global_encoder import GlobalHeteroEncoder
from medpathex_model import MedPathEx


def build_drug_sim_topk(drug_sim_file: str, n_drug: int, topk: int = 50):
    S = load_similarity_matrix(drug_sim_file)
    if S.shape[0] > n_drug:
        S = S[:n_drug, :n_drug]
    elif S.shape[0] < n_drug:
        raise ValueError(f"Drug sim matrix smaller than n_drug: {S.shape[0]} < {n_drug}")

    topk = min(topk, n_drug)
    out = []
    for i in range(n_drug):
        row = S[i].copy()
        row[i] = -1e9
        idx = np.argpartition(row, -topk)[-topk:]
        idx = idx[np.argsort(row[idx])[::-1]]
        out.append([int(j) for j in idx if row[j] > 0])
    return out


class ProjectToDim(nn.Module):

    def __init__(self, in_dis, in_drug, in_gene, dim=128):
        super().__init__()
        self.p_dis = nn.Linear(in_dis, dim)
        self.p_drug = nn.Linear(in_drug, dim)
        self.p_gene = nn.Linear(in_gene, dim)

    def forward(self, X_dis, X_drug, X_gene):
        X_dis = F.relu(self.p_dis(X_dis))
        X_drug = F.relu(self.p_drug(X_drug))
        X_gene = F.relu(self.p_gene(X_gene))
        return X_dis, X_drug, X_gene


def train_one_fold(
    A_DG_np, A_DR_np, A_DiG_np,
    train_edges, test_edges,
    H_drug_sim, H_dis_sim, H_gene_sim,
    drug_sim_topk,
    epochs=3,
    dim=128,
    lr=1e-3,
    seed=42,
    K_inst=10
):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.manual_seed(seed)
    np.random.seed(seed)

    n_dis, n_drug = A_DR_np.shape
    n_gene = A_DG_np.shape[1]

    A_DR_train_np = remove_edges_from_adj(A_DR_np, test_edges)

    neg_train = negative_sample(A_DR_train_np, num_neg=len(train_edges), seed=seed)
    pos = train_edges
    neg = neg_train
    X_pairs = np.concatenate([pos, neg], axis=0)
    y = np.concatenate([np.ones(len(pos)), np.zeros(len(neg))], axis=0)

    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(X_pairs))
    X_pairs = X_pairs[perm]
    y = y[perm]

    dis_idx  = torch.tensor(X_pairs[:, 0], dtype=torch.long, device=device)
    drug_idx = torch.tensor(X_pairs[:, 1], dtype=torch.long, device=device)
    labels   = torch.tensor(y, dtype=torch.float32, device=device)

    X_dis_np, X_drug_np, X_gene_np = build_initial_features(A_DG_np, A_DR_train_np, A_DiG_np)

    X_dis  = torch.tensor(X_dis_np, dtype=torch.float32, device=device)
    X_drug = torch.tensor(X_drug_np, dtype=torch.float32, device=device)
    X_gene = torch.tensor(X_gene_np, dtype=torch.float32, device=device)

    proj = ProjectToDim(
        in_dis=X_dis.shape[1],
        in_drug=X_drug.shape[1],
        in_gene=X_gene.shape[1],
        dim=dim
    ).to(device)

    X_dis, X_drug, X_gene = proj(X_dis, X_drug, X_gene)
    sampler = MetaPathSampler(
        A_DR_np=A_DR_train_np,
        A_DiG_np=A_DiG_np,
        A_DG_np=A_DG_np,
        drug_sim_topk=drug_sim_topk,
        seed=seed
    )
    meta_enc = MetaPathEncoderInstance(dim=dim, n_heads=4).to(device)
    H_drug_meta, H_dis_meta, H_gene_meta, _extra_meta = meta_enc(
        X_drug, X_dis, X_gene, sampler,
        K_rdr=K_inst, K_rdgdr=K_inst, K_dgd=K_inst, K_drd=K_inst, K_drrd=K_inst, K_gdrdg=K_inst
    )

    edge_index, n_dis2, n_drug2, n_gene2 = concat_hetero_edges(A_DR_train_np, A_DG_np, A_DiG_np, device=device)
    assert n_dis2 == n_dis and n_drug2 == n_drug and n_gene2 == n_gene

    global_enc = GlobalHeteroEncoder(in_dim=dim, hid_dim=dim, out_dim=dim, heads=4, n_layers=2, dropout=0.2).to(device)

    X_all = torch.cat([X_dis, X_drug, X_gene], dim=0)
    H_all_global = global_enc(X_all, edge_index)
    H_dis_global  = H_all_global[:n_dis]
    H_drug_global = H_all_global[n_dis:n_dis+n_drug]
    H_gene_global = H_all_global[n_dis+n_drug:]

    H_drug_sim = H_drug_sim.to(device)
    H_dis_sim  = H_dis_sim.to(device)
    H_gene_sim = H_gene_sim.to(device)

    model = MedPathEx(dim=dim).to(device)
    params = list(model.parameters()) + list(proj.parameters()) + list(meta_enc.parameters()) + list(global_enc.parameters())
    opt = Adam(params, lr=lr)
    loss_fn = nn.BCEWithLogitsLoss()

    model.train()
    for ep in range(1, epochs + 1):
        opt.zero_grad()
        logits, extra = model(
            dis_idx, drug_idx,
            H_drug_sim, H_dis_sim, H_gene_sim,
            H_drug_meta, H_dis_meta, H_gene_meta,
            H_drug_global, H_dis_global, H_gene_global
        )
        loss = loss_fn(logits, labels)
        loss.backward()
        opt.step()

        lam_dis = extra["lam_dis"].numpy()
        print(f"epoch {ep:02d} loss={loss.item():.4f}  lam_dis={lam_dis}")

    return model


def main():
    A_DG_np, A_DR_np, A_DiG_np = load_adjs("adjacency_matrices")
    n_dis, n_drug = A_DR_np.shape
    print("n_dis, n_drug =", n_dis, n_drug)
    drug_sim_file = "drugmerged_matrix.xlsx"
    disease_sim_file = "diseasemerged_matrix.xlsx"
    gene_sim_file = "genemerged_matrix.xlsx"

    H_drug_sim, H_dis_sim, H_gene_sim = build_similarity_embeddings(
        drug_file=drug_sim_file,
        disease_file=disease_sim_file,
        gene_file=gene_sim_file,
        out_dim=128,
        gene_topk=50,
        adj_dir="adjacency_matrices",
        gene_use_sparse=True,
        drug_use_sparse=False
    )

    drug_sim_topk = build_drug_sim_topk(drug_sim_file, n_drug=n_drug, topk=50)

    dr_edges = adj_to_edge_list(A_DR_np)
    folds = kfold_split_edges(dr_edges, k=5, seed=42)

    for i, (train_edges, test_edges) in enumerate(folds, start=1):
        print(f"\n========== Fold {i} ==========")
        _ = train_one_fold(
            A_DG_np, A_DR_np, A_DiG_np,
            train_edges, test_edges,
            H_drug_sim, H_dis_sim, H_gene_sim,
            drug_sim_topk=drug_sim_topk,
            epochs=3, dim=128, lr=1e-3, seed=42 + i,
            K_inst=10
        )


if __name__ == "__main__":
    main()