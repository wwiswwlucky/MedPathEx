import pandas as pd
import numpy as np
from pathlib import Path


def read_edge_list(file_path):
    df = pd.read_excel(file_path, header=None)
    edges = df.values.astype(int)
    edges -= 1
    return edges


def infer_node_size(edges):

    src_max = edges[:, 0].max() + 1
    dst_max = edges[:, 1].max() + 1
    return src_max, dst_max


def build_bipartite_adj(edges, num_src, num_dst):
    A = np.zeros((num_src, num_dst), dtype=np.int8)
    for s, d in edges:
        A[s, d] = 1

    return A


def build_all_adjacency(
        drug_gene_file,
        disease_drug_file,
        disease_gene_file,
        save_dir="adjacency_matrices"):

    Path(save_dir).mkdir(exist_ok=True)

    print("========== 1. Drug-Gene ==========")
    dg_edges = read_edge_list(drug_gene_file)
    drug_num, gene_num = infer_node_size(dg_edges)
    A_DG = build_bipartite_adj(dg_edges, drug_num, gene_num)
    np.save(f"{save_dir}/A_DrugGene.npy", A_DG)
    print(f"Drug-Gene matrix shape: {A_DG.shape}")
    print(f"Edges: {dg_edges.shape[0]}")

    print("\n========== 2. Disease-Drug ==========")
    dr_edges = read_edge_list(disease_drug_file)
    disease_num, drug_num2 = infer_node_size(dr_edges)
    A_DR = build_bipartite_adj(dr_edges, disease_num, drug_num2)
    np.save(f"{save_dir}/A_DiseaseDrug.npy", A_DR)
    print(f"Disease-Drug matrix shape: {A_DR.shape}")
    print(f"Edges: {dr_edges.shape[0]}")

    print("\n========== 3. Disease-Gene ==========")
    dig_edges = read_edge_list(disease_gene_file)
    disease_num2, gene_num2 = infer_node_size(dig_edges)
    A_DiG = build_bipartite_adj(dig_edges, disease_num2, gene_num2)
    np.save(f"{save_dir}/A_DiseaseGene.npy", A_DiG)
    print(f"Disease-Gene matrix shape: {A_DiG.shape}")
    print(f"Edges: {dig_edges.shape[0]}")

    print("\n✔ All adjacency matrices have been saved as .npy files")
    return A_DG, A_DR, A_DiG