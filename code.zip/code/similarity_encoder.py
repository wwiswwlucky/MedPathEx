import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from typing import Optional, Tuple


def load_similarity_matrix(file_path: str) -> np.ndarray:
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".npy":
        S = np.load(file_path).astype(np.float32)
    else:

        S = pd.read_excel(file_path, header=None).values.astype(np.float32)
    if S.ndim != 2 or S.shape[0] != S.shape[1]:
        raise ValueError(f"{file_path} is not a square matrix: {S.shape}")

    S = (S + S.T) / 2.0
    np.fill_diagonal(S, 1.0)
    return S


def crop_square_matrix(S: np.ndarray, n_keep: int, name: str) -> np.ndarray:
    N = S.shape[0]
    if N < n_keep:
        raise ValueError(
            f"{name} similarity matrix is smaller than expected: {N} < {n_keep}. "
            f"Need a mapping or correct matrix."
        )
    if N > n_keep:
        S = S[:n_keep, :n_keep]
    return S


def normalize_adj_dense(A: np.ndarray) -> np.ndarray:
    deg = A.sum(axis=1)
    deg_inv_sqrt = np.power(deg, -0.5, where=deg > 0)
    deg_inv_sqrt[~np.isfinite(deg_inv_sqrt)] = 0.0
    D = np.diag(deg_inv_sqrt.astype(np.float32))
    return (D @ A @ D).astype(np.float32)


def to_sparse_topk(A: np.ndarray, topk: int = 50) -> torch.Tensor:
    n = A.shape[0]
    rows, cols, vals = [], [], []
    topk = min(topk, n)
    for i in range(n):
        row = A[i]
        idx = np.argpartition(row, -topk)[-topk:]
        idx = idx[np.argsort(row[idx])[::-1]]

        for j in idx:
            v = float(row[j])
            if v != 0.0:
                rows.append(i)
                cols.append(int(j))
                vals.append(v)

    indices = torch.tensor([rows, cols], dtype=torch.long)
    values = torch.tensor(vals, dtype=torch.float32)
    sp = torch.sparse_coo_tensor(indices, values, size=(n, n)).coalesce()
    return sp


class SimilarityGCNDense(nn.Module):
    def __init__(self, n_nodes: int, out_dim: int):
        super().__init__()
        self.W = nn.Parameter(torch.randn(n_nodes, out_dim) * 0.01)
    def forward(self, A_norm: torch.Tensor) -> torch.Tensor:
        return A_norm @ self.W


class SimilarityGCNSparse(nn.Module):
    def __init__(self, n_nodes: int, out_dim: int):
        super().__init__()
        self.W = nn.Parameter(torch.randn(n_nodes, out_dim) * 0.01)
    def forward(self, A_sp: torch.Tensor) -> torch.Tensor:
        return torch.sparse.mm(A_sp, self.W)


def infer_sizes_from_adj(adj_dir: str) -> Tuple[int, int, int]:
    A_DR  = np.load(os.path.join(adj_dir, "A_DiseaseDrug.npy"))   # (n_dis, n_drug)
    A_DG  = np.load(os.path.join(adj_dir, "A_DrugGene.npy"))      # (n_drug, n_gene)
    A_DiG = np.load(os.path.join(adj_dir, "A_DiseaseGene.npy"))   # (n_dis, n_gene)
    n_dis, n_drug = A_DR.shape
    n_drug2, n_gene = A_DG.shape
    n_dis2, n_gene2 = A_DiG.shape
    if n_drug != n_drug2:
        raise ValueError(f"Mismatch drug size: A_DR drug={n_drug}, A_DG drug={n_drug2}")
    if n_dis != n_dis2:
        raise ValueError(f"Mismatch disease size: A_DR dis={n_dis}, A_DiG dis={n_dis2}")
    if n_gene != n_gene2:
        raise ValueError(f"Mismatch gene size: A_DG gene={n_gene}, A_DiG gene={n_gene2}")

    return n_drug, n_dis, n_gene


def build_similarity_embeddings(
    drug_file: str,
    disease_file: str,
    gene_file: str,
    out_dim: int = 128,
    gene_topk: int = 50,
    device: Optional[str] = None,
    adj_dir: Optional[str] = "adjacency_matrices",
    n_drug: Optional[int] = None,
    n_dis: Optional[int] = None,
    n_gene: Optional[int] = None,
    gene_use_sparse: bool = True,
    drug_use_sparse: bool = False,
    drug_topk: int = 100
):
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    if (n_drug is None) or (n_dis is None) or (n_gene is None):
        if adj_dir is None:
            raise ValueError("Please provide adj_dir or manually set n_drug/n_dis/n_gene.")
        n_drug, n_dis, n_gene = infer_sizes_from_adj(adj_dir)
    S_drug = load_similarity_matrix(drug_file)
    S_drug = crop_square_matrix(S_drug, n_drug, "Drug")
    A_drug = normalize_adj_dense(S_drug)
    if drug_use_sparse:
        A_drug_sp = to_sparse_topk(A_drug, topk=drug_topk).to(device)
        drug_gcn = SimilarityGCNSparse(n_drug, out_dim).to(device)
        H_drug_sim = drug_gcn(A_drug_sp)
    else:
        A_drug_t = torch.tensor(A_drug, dtype=torch.float32, device=device)
        drug_gcn = SimilarityGCNDense(n_drug, out_dim).to(device)
        H_drug_sim = drug_gcn(A_drug_t)
    S_dis = load_similarity_matrix(disease_file)
    S_dis = crop_square_matrix(S_dis, n_dis, "Disease")
    A_dis = normalize_adj_dense(S_dis)
    A_dis_t = torch.tensor(A_dis, dtype=torch.float32, device=device)
    dis_gcn = SimilarityGCNDense(n_dis, out_dim).to(device)
    H_dis_sim = dis_gcn(A_dis_t)
    S_gene = load_similarity_matrix(gene_file)
    S_gene = crop_square_matrix(S_gene, n_gene, "Gene")
    A_gene = normalize_adj_dense(S_gene)
    if gene_use_sparse:
        A_gene_sp = to_sparse_topk(A_gene, topk=gene_topk).to(device)
        gene_gcn = SimilarityGCNSparse(n_gene, out_dim).to(device)
        H_gene_sim = gene_gcn(A_gene_sp)
    else:
        A_gene_t = torch.tensor(A_gene, dtype=torch.float32, device=device)
        gene_gcn = SimilarityGCNDense(n_gene, out_dim).to(device)
        H_gene_sim = gene_gcn(A_gene_t)

    return H_drug_sim, H_dis_sim, H_gene_sim