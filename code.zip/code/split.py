import numpy as np

def kfold_split_edges(edges, k=5, seed=42):
    rng = np.random.default_rng(seed)
    idx = np.arange(len(edges))
    rng.shuffle(idx)
    folds = np.array_split(idx, k)

    out = []
    for i in range(k):
        test_idx = folds[i]
        train_idx = np.concatenate([folds[j] for j in range(k) if j != i])
        out.append((edges[train_idx], edges[test_idx]))
    return out

def remove_edges_from_adj(A, edges):
    A2 = A.copy()
    A2[edges[:,0], edges[:,1]] = 0
    return A2

def negative_sample(A_pos, num_neg, seed=42):
    rng = np.random.default_rng(seed)
    n_dis, n_drug = A_pos.shape

    neg_edges = []
    seen = set()
    while len(neg_edges) < num_neg:
        d = int(rng.integers(0, n_dis))
        r = int(rng.integers(0, n_drug))
        if A_pos[d, r] == 0:
            key = d * n_drug + r
            if key not in seen:
                seen.add(key)
                neg_edges.append((d, r))
    return np.array(neg_edges, dtype=int)

